export class Conection {

    // Com que js no suporta "private", hem de definir
    // el patró singleton en el propi constructor.
    constructor() {
        
    }
    
}